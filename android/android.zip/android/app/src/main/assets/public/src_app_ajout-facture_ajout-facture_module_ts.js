(self["webpackChunkfacture"] = self["webpackChunkfacture"] || []).push([["src_app_ajout-facture_ajout-facture_module_ts"],{

/***/ 6839:
/*!***************************************************************!*\
  !*** ./src/app/ajout-facture/ajout-facture-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AjoutFacturePageRoutingModule": () => (/* binding */ AjoutFacturePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ajout_facture_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ajout-facture.page */ 6035);




const routes = [
    {
        path: '',
        component: _ajout_facture_page__WEBPACK_IMPORTED_MODULE_0__.AjoutFacturePage
    }
];
let AjoutFacturePageRoutingModule = class AjoutFacturePageRoutingModule {
};
AjoutFacturePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AjoutFacturePageRoutingModule);



/***/ }),

/***/ 93:
/*!*******************************************************!*\
  !*** ./src/app/ajout-facture/ajout-facture.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AjoutFacturePageModule": () => (/* binding */ AjoutFacturePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _ajout_facture_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ajout-facture-routing.module */ 6839);
/* harmony import */ var _ajout_facture_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ajout-facture.page */ 6035);







let AjoutFacturePageModule = class AjoutFacturePageModule {
};
AjoutFacturePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ajout_facture_routing_module__WEBPACK_IMPORTED_MODULE_0__.AjoutFacturePageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_ajout_facture_page__WEBPACK_IMPORTED_MODULE_1__.AjoutFacturePage]
    })
], AjoutFacturePageModule);



/***/ }),

/***/ 6035:
/*!*****************************************************!*\
  !*** ./src/app/ajout-facture/ajout-facture.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AjoutFacturePage": () => (/* binding */ AjoutFacturePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_ajout_facture_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./ajout-facture.page.html */ 6759);
/* harmony import */ var _ajout_facture_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ajout-facture.page.scss */ 2158);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _services_factures_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/factures.service */ 4112);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);







let AjoutFacturePage = class AjoutFacturePage {
    constructor(formBuilder, fact, alertC) {
        this.formBuilder = formBuilder;
        this.fact = fact;
        this.alertC = alertC;
    }
    ngOnInit() {
        this.init();
    }
    init() {
        this.ajoutForm = this.formBuilder.group({
            client: [''],
            produit: [''],
            quantite: ['']
        });
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.clients = yield this.fact.getClient();
            this.produits = yield this.fact.getProduit();
        });
    }
    onSubmit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertC.create({
                cssClass: 'primary',
                message: 'voulez vous vraiment enregistrer cette commande',
                header: 'confirmation',
                buttons: [{
                        text: 'cancel',
                        role: 'cancel'
                    },
                    {
                        text: 'ok',
                        handler: () => {
                            this.post();
                        }
                    }
                ]
            });
            alert.present();
            //  this.obs.pipe(
            //     catchError(
            //       (err : any) => {
            //         console.log('there was an error', err);
            //       }
            //     )
            //   )
        });
    }
    post() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const form = yield this.ajoutForm.value;
            console.log(form);
            if (form.quantite < 1) {
                console.log('this.form is not valid');
            }
            else {
                console.log('valid');
                const formated = { facture_client: form.client, produit: form.produit.id, quantite: form.quantite };
                console.log(formated);
                this.obs = yield this.fact.postFacture(formated);
                this.obs.subscribe();
            }
            console.log('form submited');
        });
    }
};
AjoutFacturePage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _services_factures_service__WEBPACK_IMPORTED_MODULE_2__.FacturesService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController }
];
AjoutFacturePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-ajout-facture',
        template: _raw_loader_ajout_facture_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_ajout_facture_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AjoutFacturePage);



/***/ }),

/***/ 2158:
/*!*******************************************************!*\
  !*** ./src/app/ajout-facture/ajout-facture.page.scss ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-card {\n  min-width: 300px;\n}\n\nion-select::part(placeholder) {\n  width: 30%;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFqb3V0LWZhY3R1cmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUFDRjs7QUFLQTtFQUVFLFVBQUE7RUFDQSxZQUFBO0FBSEYiLCJmaWxlIjoiYWpvdXQtZmFjdHVyZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZHtcclxuICBtaW4td2lkdGg6IDMwMHB4O1xyXG5cclxufVxyXG5cclxuXHJcblxyXG5pb24tc2VsZWN0OjpwYXJ0KHBsYWNlaG9sZGVyKXtcclxuXHJcbiAgd2lkdGg6IDMwJTtcclxuICBtYXJnaW46IGF1dG87XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 6759:
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ajout-facture/ajout-facture.page.html ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n\n</ion-header>\n\n<ion-content>\n\n\n\n\n\n<ion-grid class=\"ion-align-self-auto\">\n  <ion-row>\n    <ion-col size-md=\"6\" offset-md=\"3\" size-sm=\"8\" offset-sm=\"2\">\n      <ion-item>\n        <ion-title class=\"ion-align-items-center\" color=\"primary\" class=\"ion-align-items-center\">Ajouter une facture</ion-title>\n\n      </ion-item>\n\n   <form [formGroup]=\"ajoutForm\" (ngSubmit)=\"onSubmit()\">\n    <ion-card class=\"ion-padding\">\n\n        <ion-item class=\"ion-margin\">\n          <ion-label position=\" floating\" >Client</ion-label>\n          <ion-select  value=\"peperoni\" placeholder=\"Select client\" formControlName=\"client\" [(ngModel)] = \"clientSelect\">\n\n            <ng-container *ngFor=\"let item of clients|async\" >\n              <ion-select-option [value]=\"item.id\">{{item.nom}}</ion-select-option>\n            </ng-container>\n          </ion-select>\n        </ion-item>\n\n     <ion-item>\n       <ion-label position=\"floating\" class=\"ion-align-items-start\" >Produit</ion-label>\n      <ion-select value=\"peperoni\" placeholder=\"Select produit\" formControlName=\"produit\" [(ngModel)] = \"produitSelect\">\n\n        <ng-container *ngFor=\"let item of produits|async\" >\n          <ion-select-option [value]=\"item\"> {{item.nom}}</ion-select-option>\n        </ng-container>\n\n      </ion-select>\n    </ion-item>\n\n      <ion-item class=\"ion-margin \">\n        <ion-label class=\"ion-align-items-start\" position=\"floating\">Quantite</ion-label>\n        <ion-input formControlName=\"quantite\" type=\"number\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label class=\"ion-align-items-start\" >client: </ion-label> <ion-text color=\"primary\">\n          <h3>{{ produitSelect?.nom}}</h3>\n        </ion-text>\n      </ion-item>\n      <ion-item>\n        <ion-label class=\"ion-align-items-start\" >produit: </ion-label> <ion-text color=\"primary\">\n          <h3>{{clientSelect?.nom}}</h3>\n        </ion-text>\n      </ion-item>\n\n\n    </ion-card>\n\n      <ion-button fill =\"outline\"  color=\"danger\" expand=\"block\"  (click)= \"init()\" class=\"cancel ion-padding ion-margin\">\n        <ion-icon slot=\"start\" name=\"delete\" color=\"danger\"></ion-icon>\n        cancel\n      </ion-button>\n  <ion-button   color=\"primary\"  expand=\"block\"  type=\"submit\" [disabled]=\"ajoutForm.invalid\"class=\"ion-padding ion-margin\">\n  ajouter\n  </ion-button>\n\n  </form>\n\n    </ion-col>\n\n  </ion-row>\n\n\n</ion-grid>\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_ajout-facture_ajout-facture_module_ts.js.map