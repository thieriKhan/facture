(self["webpackChunkfacture"] = self["webpackChunkfacture"] || []).push([["src_app_nav-bar_nav-bar_module_ts"],{

/***/ 2668:
/*!***************************************************!*\
  !*** ./src/app/nav-bar/nav-bar-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavBarPageRoutingModule": () => (/* binding */ NavBarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _nav_bar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nav-bar.page */ 2670);




const routes = [
    {
        path: '',
        component: _nav_bar_page__WEBPACK_IMPORTED_MODULE_0__.NavBarPage,
        children: [
            {
                path: 'impression-facture',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_factures_service_ts"), __webpack_require__.e("src_app_impression-facture_impression-facture_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../impression-facture/impression-facture.module */ 4922)).then(m => m.ImpressionFacturePageModule)
            },
            {
                path: 'ajout-facture',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_services_factures_service_ts"), __webpack_require__.e("src_app_ajout-facture_ajout-facture_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../ajout-facture/ajout-facture.module */ 93)).then(m => m.AjoutFacturePageModule)
            },
            {
                path: '',
                redirectTo: 'ajout-facture'
            }
        ]
    }
];
let NavBarPageRoutingModule = class NavBarPageRoutingModule {
};
NavBarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NavBarPageRoutingModule);



/***/ }),

/***/ 4562:
/*!*******************************************!*\
  !*** ./src/app/nav-bar/nav-bar.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavBarPageModule": () => (/* binding */ NavBarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _nav_bar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nav-bar-routing.module */ 2668);
/* harmony import */ var _nav_bar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nav-bar.page */ 2670);







let NavBarPageModule = class NavBarPageModule {
};
NavBarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _nav_bar_routing_module__WEBPACK_IMPORTED_MODULE_0__.NavBarPageRoutingModule
        ],
        declarations: [_nav_bar_page__WEBPACK_IMPORTED_MODULE_1__.NavBarPage]
    })
], NavBarPageModule);



/***/ }),

/***/ 2670:
/*!*****************************************!*\
  !*** ./src/app/nav-bar/nav-bar.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavBarPage": () => (/* binding */ NavBarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_nav_bar_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./nav-bar.page.html */ 9092);
/* harmony import */ var _nav_bar_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./nav-bar.page.scss */ 6109);
/* harmony import */ var _services_login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../services/login.service */ 4120);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/storage.service */ 1188);






let NavBarPage = class NavBarPage {
    constructor(storage, log) {
        this.storage = storage;
        this.log = log;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.user = yield this.storage.get('user');
        });
    }
    logout() {
        this.log.logout();
    }
};
NavBarPage.ctorParameters = () => [
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__.StorageService },
    { type: _services_login_service__WEBPACK_IMPORTED_MODULE_2__.LoginService }
];
NavBarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-nav-bar',
        template: _raw_loader_nav_bar_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_nav_bar_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], NavBarPage);



/***/ }),

/***/ 6109:
/*!*******************************************!*\
  !*** ./src/app/nav-bar/nav-bar.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-tool-bar {\n  --border-style: none;\n}\n\nion-tab-button.tab-selected {\n  border-bottom: 2px solid var(--ion-color-primary);\n}\n\nion-buttons {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n}\n\nion-buttons ion-button ion-icon {\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5hdi1iYXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQW1CQTtFQUNFLG9CQUFBO0FBbEJGOztBQWdDQTtFQUdBLGlEQUFBO0FBL0JBOztBQTRDQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7QUF6Q0Y7O0FBMkNJO0VBQ0UsWUFBQTtBQXpDTiIsImZpbGUiOiJuYXYtYmFyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGlvbi10YWItYmFye1xyXG4gIC8vIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAvLyB0b3A6IDA7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XHJcbiAgLy8gYm9yZGVyLWJvdHRvbTogMnB4IHNvbGlkIGdyYXk7XHJcbiAgLy8gYm94LXNoYWRvdzogMCAycHggIHJnYigxNDYsIDEzMSwgMTMxKTtcclxuICAvLyBpb24tdGFiLWJ1dHRvbntcclxuICAvLyAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcclxuXHJcblxyXG4gIC8vIH1cclxuICAvLyBpb24tdGFiLWJ1dHRvbjphY3RpdmV7XHJcbiAgLy8gICBjb2xvcjogZ3JlZW47XHJcbiAgLy8gfVxyXG5cclxuXHJcblxyXG4vLyB9XHJcblxyXG5pb24tdG9vbC1iYXJ7XHJcbiAgLS1ib3JkZXItc3R5bGU6IG5vbmU7XHJcbn1cclxuXHJcblxyXG5cclxuLy8gaW9uLXRhYi1iYXJ7XHJcbi8vICAgaGVpZ2h0OiAyMCU7XHJcbi8vICAgaW9uLXRhYi1idXR0b257XHJcbi8vICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMTk5LCAxNzgsIDE3OCkoMTk5LCAxNzgsIDE3OCkoMTk5LCAxNzgsIDE3OCk7XHJcbi8vICAgICBoZWlnaHQ6IGF1dG87XHJcbi8vICAgfVxyXG4vLyB9XHJcblxyXG5cclxuaW9uLXRhYi1idXR0b24udGFiLXNlbGVjdGVke1xyXG5cclxuXHJcbmJvcmRlci1ib3R0b20gOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcbi8vIC5idG57XHJcbi8vICAgbWluLXdpZHRoOiA0MHB4O1xyXG4vLyAgIGlvbi1sYWJlbHtcclxuXHJcbi8vICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbi8vICAgICBsZWZ0OiAzMnB4O1xyXG4vLyAgICAgIGJvdHRvbTogMjBweDtcclxuLy8gICB9XHJcbi8vIH1cclxuXHJcblxyXG5pb24tYnV0dG9uc3tcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxMHB4O1xyXG4gIHJpZ2h0OiAxMHB4O1xyXG4gIGlvbi1idXR0b257XHJcbiAgICBpb24taWNvbntcclxuICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 9092:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/nav-bar/nav-bar.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar >\n    <ion-title>Factures</ion-title>\n    <ion-buttons class=\"ion-no-margin ion-no-padding\"  slot=\"end\" >\n      <ion-label>{{user}}</ion-label>\n      <ion-button slot=\"end\" class=\"ion-no-padding\"class=\"ion-no-padding\" (click)=\"logout()\" >\n        <ion-icon slot=\"icon-only\" color=\"primary\" name=\"log-out\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n\n\n  <ion-tabs color=\"primary\" class=\"ion-no-padding\">\n    <ion-tab-bar slot=\"top\"  >\n\n      <ion-tab-button tab=\"ajout-facture\" >\n        <ion-label>Ajouter</ion-label>\n      </ion-tab-button>\n      <ion-tab-button tab=\"impression-facture\" class=\"ion-no-padding marge\">\n\n        <ion-label>Imprimer</ion-label>\n      </ion-tab-button>\n\n\n\n\n\n\n    </ion-tab-bar>\n\n\n\n  </ion-tabs>\n\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_nav-bar_nav-bar_module_ts.js.map